import { Component, DoCheck, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit,DoCheck {
  msg:any=[];
  constructor(private dataService:DataService) { }
  

  ngOnInit(): void {
  }
  ngDoCheck(): void {
    this.msg=this.dataService.callData();
  }
  send(msg:any)
  {
    this.msg=this.dataService.getData("admin:"+msg);
  }

}
