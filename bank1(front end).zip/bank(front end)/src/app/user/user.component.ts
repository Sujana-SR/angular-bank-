import { Component, DoCheck, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit ,DoCheck{

  msg:any=[];
  constructor(private data1:DataService) { }
  ngDoCheck(): void {
    this.msg=this.data1.callData();
  }

  ngOnInit(): void {
  }

  send(msg:any)
  {

    this.msg=this.data1.getData("user:"+msg);
    this.msg=`user:${msg}`;
  }

}
